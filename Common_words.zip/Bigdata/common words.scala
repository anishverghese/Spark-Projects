
object wordcount{
    def main(args: Array[String]){

     import org.apache.spark.rdd.RD
     val rd1 = sc.textFile("C:\Users\91833\OneDrive - Mahindra University\Desktop\Bigdata\task1-input1.txt")
     val rd2 = sc.textFile("C:\Users\91833\OneDrive - Mahindra University\Desktop\Bigdata\task1-input2.txt")

     val rdd1 = rd1.flatMap(_.split(","))

     val f1  = rdd1.flatMap(_.split(" "))

     val ff1 = f1.filter(x=>x!="")

     val rdd2 = rd2.flatMap(_.split(","))

     val f2 = rdd2.flatMap(_.split(","))

     val ff2 = f2.filter(x=>x!="")

     val a = ff1.intersection(ff2)

     a.collect()foreach(println)

     a.count()
    

     val sub = sc.textFile("C:\Users\91833\Downloads\stopwords.txt") //stopwords.txt

     val b = a.subtract(sub)

     b.count()
   

     b.saveAsTextFile("C:\Users\91833\OneDrive - Mahindra University\Desktop\output")
     sc.stop
   }
}



