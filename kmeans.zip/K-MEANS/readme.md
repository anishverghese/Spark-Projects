                   							      K-Means Clustering with Apache Spark
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
version used:
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
java -version
      openjdk version "11.0.16" 2022-07-19
      OpenJDK Runtime Environment (build 11.0.16+8-post-Ubuntu-0ubuntu122.04)
      OpenJDK 64-Bit Server VM (build 11.0.16+8-post-Ubuntu-0ubuntu122.04, mixed mode, sharing)

used spark version 3.4.0 hadoop 3
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
The Code for the project:
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    val rd = sc.textFile("/home/anish/Downloads/BD_EDITED.txt")

    val f = rd.flatMap(_.split(","))

    val df= f.map(_.toDouble)

    var centroid = List((4.6,3.1,1.5,0.2),(5.0,2.0,3.5,1.0),(7.9,3.8,6.4,2.0))

    import scala.math.{sqrt, pow}
    var isAbsoluteDifferenceLessThanOne = false 
    var flag = 0
    do
    {
    var currMinIndex = -1
    var currMinDistance = Double.MaxValue

    val resultRDD: RDD[(Double, Double, Double, Double, Int)] = df.mapPartitions { partition =>
    val resultList = scala.collection.mutable.ListBuffer.empty[(Double, Double, Double, Double, Int)]

    for (i <- partition.grouped(4)) {
        var count = 0
        var minIndex = -1
        var minDistance = Double.MaxValue
        
    for (j <- 0 until centroid.size) {
        count += 1
        
        val distance = math.sqrt(
            math.pow(centroid(j)._1 - i(0).toDouble, 2) +
            math.pow(centroid(j)._2 - i(1).toDouble, 2) +
            math.pow(centroid(j)._3 - i(2).toDouble, 2) +
            math.pow(centroid(j)._4 - i(3).toDouble, 2)
        )
        
        if (distance < minDistance) {
            minIndex = count
            minDistance = distance
        }
        }
        
        resultList += ((i(0).toDouble, i(1).toDouble, i(2).toDouble, i(3).toDouble, minIndex))
    }
    
    resultList.iterator
    }

    val meanRDD = resultRDD.groupBy(_._5).mapValues { groupedValues =>val sum = groupedValues.foldLeft((0.0, 0.0, 0.0, 0.0)) { case (acc, (x, y, z, w, _)) =>(acc._1 + x, acc._2 + y, acc._3 + z, acc._4 + w)}
        val count = groupedValues.size.toDouble
        (sum._1 / count, sum._2 / count, sum._3 / count, sum._4 / count)
        }
        
    val sortedRDD = meanRDD.sortBy(_._1)

    val list = sortedRDD.map(_._2).collect()
    val rdd1 = sc.parallelize(list)
    val rdd2 = sc.parallelize(centroid)
    val absoluteDifferenceRDD: RDD[(Double, Double, Double, Double)] = rdd1.zip(rdd2).map {
        case ((x1, y1, z1, w1), (x2, y2, z2, w2)) =>
        (math.abs(x1 - x2), math.abs(y1 - y2), math.abs(z1 - z2), math.abs(w1 - w2))}
    val absoluteDifferences = absoluteDifferenceRDD.collect()

    val isAbsoluteDifferenceLessThanOne = absoluteDifferences.forall{case (x, y, z, w) => x < 1 && y < 1 && z < 1 && w < 1}

    centroid = sortedRDD.map(_._2).collect().toList
    flag = 1
    resultRDD.collect()foreach(println)
    }while (!isAbsoluteDifferenceLessThanOne)

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Code Explanation:
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Reads a text file from the specified path and splits each line by comma.
Converts each element to a Double.

Initializes a list of centroids.

Enters a loop to iterate until the condition isAbsoluteDifferenceLessThanOne is true.

Maps each element of the RDD to the closest centroid based on Euclidean distance calculation.

Calculates the new mean for each centroid based on the assigned points.

Sorts the centroids based on the first value.

Collects the centroids as a list and creates new RDDs from the list and the previous centroids.

Calculates the absolute difference between the new and previous centroids.

Checks if the absolute difference for all coordinates is less than one.

Updates the centroids with the new values and sets the flag to 1.

Collects the results and prints them.

Continues the loop if the absolute difference condition is not met.
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Steps to execute the above code in spark-shell
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
1) save the above code in the .scala file named as kmeans.scala
2) execute command spark-shell on the terminal which runs the sparksession
3) load the file using :load command in the spark which is (:load kmeans.scala)
4) it will compile the object kmeans
5) run the file by executing = kmeans.main(Array()) 
6) it will run the code and save the output as part-0000,part-0001
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Results:
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
The code outputs the assigned data points to each centroid for each iteration of the k-means algorithm. Additionally, it prints the final result of the clustering.
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------